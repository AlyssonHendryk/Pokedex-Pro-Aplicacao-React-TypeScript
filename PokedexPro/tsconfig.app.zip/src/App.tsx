import Header from "./components/layout/header/logo"
import './App.css'
import { SearchInput } from "./features/pokemons/components/SearchInput"

export default function App() {
    return (
        <div className="main">
            <Header />
            <main>
                <div className="search-container">
                    <SearchInput />
                </div>
            </main>
        </div>
    )
}