import type { Pokemon } from "../types/pokemon";

export async function fetchPokemon(
  nameOrId: string | number
): Promise<Pokemon> {

  const response = await fetch(
    `https://pokeapi.co/api/v2/pokemon/${nameOrId}`
  );

  if (!response.ok) {
    throw new Error("Pokémon não encontrado");
  }

  return response.json();
}