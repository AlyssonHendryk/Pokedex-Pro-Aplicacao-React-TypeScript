<SearchInput
  value={search}
  onChange={setSearch}
/>